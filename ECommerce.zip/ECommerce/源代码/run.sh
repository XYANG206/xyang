#!/bin/bash

# submit spark job
spark-submit project.py
# start web server
python3 web.py